using PaymentAPI.Configuration;

namespace PaymentAPI.Models.DTOs.Responses
{
    public class GlobalResponse : ApiGlobalResult
    {
        
    }
}