namespace MoviesAPI.Configuration
{
    public class JwtConfig
    {
        public string Secret{ get; set;}
    }
}