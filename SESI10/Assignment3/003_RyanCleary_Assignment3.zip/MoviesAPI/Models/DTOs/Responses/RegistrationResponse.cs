using MoviesAPI.Configuration;

namespace MoviesAPI.Models.DTOs.Responses
{
    public class RegistrationResponse : AuthResult
    {
        
    }
}